full_dataset = [
    {'name': 'Peach', 'items': ['green shell', 'banana', 'green shell',], 'finish': 3},
    {'name': 'Peach', 'items': ['green shell', 'banana', 'green shell',], 'finish': 1},
    {'name': 'Bowser', 'items': ['green shell',], 'finish': 1},
    {'name': None, 'items': ['green shell',], 'finish': 2},
    {'name': 'Bowser', 'items': ['green shell',], 'finish': 1},
    {'name': None, 'items': ['red shell',], 'finish': 1},
    {'name': 'Yoshi', 'items': ['banana', 'blue shell', 'banana'], 'finish': 7},
    {'name': 'DK', 'items': ['blue shell', 'star',], 'finish': 1},
]
